########################################################

AL PRIMO AVVIO

* Inserire il percorso del file r script (di solito C:\Program Files\R\R-3.6.1\bin)
* Se trova l'eseguibile rscript.exe, la console crea un file r-config.json con all'interno il percorso salvato 
   e appare un menu
* Inserendo 1 si potr� eseguire un file r direttamente da console
* Si inserisce il nome del file r SENZA l'estensione del file (es. test anzich� test.r)
* IMPORTANTE: il file r deve essere nella stessa directory della console